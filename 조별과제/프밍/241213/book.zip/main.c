#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include "user.h"

client_s *client_head = NULL;
book_s *book_head = NULL;
borrow_s *borrow_head = NULL;
int loop_main = 1;
int N = 0;

void get_client() {
    FILE *cl = fopen("client", "r");
    if (cl == NULL) {
        printf("클라이언트 파일을 열 수 없습니다.\n");
        return;
    }

    while (1) {
        client_s *temp = (client_s *)malloc(sizeof(client_s));
        if (temp == NULL) {
            printf("메모리 할당 실패\n");
            fclose(cl);
            return;
        }

        // fscanf로 데이터를 읽어옵니다.
        int result = fscanf(cl, "%d | %s | %s | %[^|] | %s", 
                            &temp->studentnum,
                            temp->password,
                            temp->name,
                            temp->address,
                            temp->phonenum);
        int len = strlen(temp->address);
        while (len > 0 && temp->address[len - 1] == ' ') {
            temp->address[len - 1] = '\0';
            len--;
        }

        if (result == 5) { // 성공적으로 모든 데이터를 읽은 경우
            temp->next = NULL;

            if (client_head == NULL) {
                client_head = temp; // 첫 노드인 경우
            } else {
                client_s *cur = client_head;
                while (cur->next != NULL) {
                    cur = cur->next;
                }
                cur->next = temp; // 마지막 노드에 추가
            }
        } else { // fscanf 실패 시 메모리 해제 및 루프 종료
            free(temp);
            break;
        }
    }

    fclose(cl);

    // 연결 리스트 출력
/*    client_s *cur = client_head; // 출력용 포인터
    while (cur != NULL) {
        printf("Student Number: %d, Name: %s, Address: %s, Phone: %s\n\n",
               cur->studentnum, cur->name, cur->address, cur->phonenum);
        cur = cur->next;
    } */
}


void get_book() {
    FILE *bk = fopen("book", "r");
    if (bk == NULL) {
        printf("도서 파일을 열 수 없습니다.\n");
        return;
    }

    while (1) {
        book_s *temp = (book_s *)malloc(sizeof(book_s));
        if (temp == NULL) {
            printf("메모리 할당 실패\n");
            fclose(bk);
            return;
        }

        // fscanf로 데이터를 읽어옵니다.
        int result = fscanf(bk, "%d | %s | %s | %s | %lld | %s | %c",
                            &temp->booknum,
                            temp->bookname,
                            temp->publisher,
                            temp->author,
                            &temp->ISBN,
                            temp->location,
                            &temp->available);

        if (result == 7) { // 성공적으로 모든 데이터를 읽은 경우
            temp->next = NULL;
	N++;

            if (book_head == NULL) {
                book_head = temp; // 첫 노드인 경우
            } else {
                book_s *cur = book_head;
                while (cur->next != NULL) {
                    cur = cur->next;
                }
                cur->next = temp; // 마지막 노드에 추가
            }
        } else { // fscanf 실패 시 메모리 해제 및 루프 종료
            free(temp);
            break;
        }
    }

    fclose(bk);
}


void get_borrow() {
    FILE *br = fopen("borrow", "r");
    if (br == NULL) {
        printf("대여 파일을 열 수 없습니다.\n");
        return;
    }

    while (1) {
        borrow_s *temp = (borrow_s *)malloc(sizeof(borrow_s));
        if (temp == NULL) {
            printf("메모리 할당 실패\n");
            fclose(br);
            return;
        }

        // fscanf로 데이터를 읽어옵니다.
        int result = fscanf(br, "%d %d %ld %ld",
                            &temp->studentnum,
                            &temp->booknum,
                            &temp->borrowdate,
                            &temp->returndate);

        if (result == 4) { // 성공적으로 모든 데이터를 읽은 경우
            temp->next = NULL;

            if (borrow_head == NULL) {
                borrow_head = temp; // 첫 노드인 경우
            } else {
                borrow_s *cur = borrow_head;
                while (cur->next != NULL) {
                    cur = cur->next;
                }
                cur->next = temp; // 마지막 노드에 추가
            }
        } else { // fscanf 실패 시 메모리 해제 및 루프 종료
            free(temp);
            break;
        }
    }

    fclose(br);
}


void sort_clients() {
    client_s *i, *j;
    int temp_studentnum;
    char temp_password[15], temp_name[20], temp_address[20], temp_phonenum[20];

    for (i = client_head; i != NULL; i = i->next) {
        for (j = i->next; j != NULL; j = j->next) {
            if (i->studentnum > j->studentnum) {
                // studentnum 교환
                temp_studentnum = i->studentnum;
                i->studentnum = j->studentnum;
                j->studentnum = temp_studentnum;

                // password 교환
                strcpy(temp_password, i->password);
                strcpy(i->password, j->password);
                strcpy(j->password, temp_password);

                // name 교환
                strcpy(temp_name, i->name);
                strcpy(i->name, j->name);
                strcpy(j->name, temp_name);

                // address 교환
                strcpy(temp_address, i->address);
                strcpy(i->address, j->address);
                strcpy(j->address, temp_address);

                // phonenum 교환
                strcpy(temp_phonenum, i->phonenum);
                strcpy(i->phonenum, j->phonenum);
                strcpy(j->phonenum, temp_phonenum);
            }
        }
    }
}


void sort_books() {
    book_s *i, *j;
    int temp_booknum;
    long long temp_ISBN;
    char temp_bookname[30], temp_publisher[30], temp_author[20], temp_location[30];
    char temp_available;

    for (i = book_head; i != NULL; i = i->next) {
        for (j = i->next; j != NULL; j = j->next) {
            if (i->ISBN > j->ISBN) {
                // ISBN 교환
                temp_ISBN = i->ISBN;
                i->ISBN = j->ISBN;
                j->ISBN = temp_ISBN;

                // booknum 교환
                temp_booknum = i->booknum;
                i->booknum = j->booknum;
                j->booknum = temp_booknum;

                // bookname 교환
                strcpy(temp_bookname, i->bookname);
                strcpy(i->bookname, j->bookname);
                strcpy(j->bookname, temp_bookname);

                // publisher 교환
                strcpy(temp_publisher, i->publisher);
                strcpy(i->publisher, j->publisher);
                strcpy(j->publisher, temp_publisher);

                // author 교환
                strcpy(temp_author, i->author);
                strcpy(i->author, j->author);
                strcpy(j->author, temp_author);

                // location 교환
                strcpy(temp_location, i->location);
                strcpy(i->location, j->location);
                strcpy(j->location, temp_location);

                // available 교환
                temp_available = i->available;
                i->available = j->available;
                j->available = temp_available;
            }
        }
    }
}


int membership(){
    int studentnum;
    char password[15], name[20], address[20], phonenum[20];
    client_s *cur = client_head;
    printf("회원 가입을 시작합니다.\n");
    int new = 0;
    while (!new){
        new = 1;
        printf("학번: ");
        scanf("%d", &studentnum);
        while (cur !=NULL){
            if (cur->studentnum == studentnum){
                printf("이미 존재하는 학번입니다.\n");
                new = 0;
                break;
            }
            cur = cur->next;
        }
    }
    printf("비밀번호: ");
    scanf("%s", password);
    printf("이름: ");
    scanf("%s", name);
    printf("주소: ");
    scanf("%s", address);
    printf("전화번호: ");
    scanf("%s", phonenum);
    
    client_s *new_client;
    new_client = (client_s *)malloc(sizeof(client_s));
    new_client->studentnum = studentnum;
    strcpy(new_client->password, password);
    strcpy(new_client->name, name);
    strcpy(new_client->address, address);
    strcpy(new_client->phonenum, phonenum);
    new_client->next = client_head;
    client_head = new_client;
    sort_clients();
    FILE *cl = fopen("client file.txt","w");
    cur = client_head;
    while (cur != NULL) {
        fprintf(cl, "%d | %s | %s | %s | %s\n",cur->studentnum, cur->password, cur->name, cur->address, cur->phonenum);
        cur = cur->next;
    }
    fclose(cl);
    printf("회원 가입이 완료되었습니다.\n\n\n"); // "Enter을 눌러 메뉴로 이동하세요." 부분 삭제
    while(getchar()!='\n');
    //system("clear"); TODO : clear 삭제 
    //client_func(studentnum);
    return 1;
}

int login() {
    client_s *now = client_head;
    char logname[15];
    char password[15];

    printf("로그인 시작\n");
    printf("학번: ");
    scanf("%s", logname);
    printf("비밀번호: ");
    scanf("%s", password);

    // 관리자 로그인
    if (strcmp(logname, "admin") == 0) {
        if (strcmp(password, "lib_admin7") == 0) {
            printf("관리자님, 반갑습니다.\n");
            // 관리자 기능 호출
            admin_func();
            return 0;
        } else {
            printf("관리자 비밀번호가 틀렸습니다.\n");
            return 0;
        }
    }

    // 일반 사용자 로그인
    int num = atoi(logname);
    if (num == 0) {
        printf("유효하지 않은 학번입니다.\n");
        return 0;
    }

    while (now != NULL) {
        if (num == now->studentnum && strcmp(now->password, password) == 0) {
            printf("%s님, 반갑습니다.\n", now->name);
            // 사용자 기능 호출
            client_func(num);
            return 0;
        }
        now = now->next;
    }

    printf("로그인명 혹은 비밀번호가 일치하지 않습니다.\n");
    return 0;
}


int libservice() {
START:
    int num;
    printf(">> 도서관 서비스 <<\n");
    printf("1. 회원 가입        2. 로그인        3. 프로그램 종료\n");
    printf("\n번호를 선택하세요: ");
    scanf("%d", &num);

    if (num == 1) {
        membership();
        // TODO
        goto START;
    } else if (num == 2) {
        login();
    } else {
        loop_main = 0;
        return 0;
    }
    return 1;
}

int main() {
    do {
        get_client();    
        get_book();
        get_borrow();
        sort_clients();
        sort_books();
        libservice();
    } while(loop_main);	

    return 0;
}
